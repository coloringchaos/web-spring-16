/* 	this demo shows how we can send messages 
	to the html document with javascript 
	there are 3 ways to send messages
*/

alert("this is an alert");

document.write("<h1>Javascript Messages</h1>");

console.log("this is a message to the console");

//this function lets us click on the gray box on our page
//this function will be called by the html onclick
//when the function is called, an alert will run
function box1(){
	/*anything inside this function will happen 
	when the div is clicked */
	console.log("box 1 was clicked");
	alert("box 1 was clicked!");
}



















